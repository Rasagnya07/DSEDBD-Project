# Interview Practice Platform — Frontend

Course project (25CS1302E) frontend demo. React + Vite + Tailwind CSS v4 + React Router + Recharts.

## Run it locally

```bash
npm install
npm run dev
```

Then open the printed localhost URL. Start at `/dashboard`.

## What's real vs mocked

- All screens are fully functional React UI with real navigation, state, and interactions.
- Data (jobs, companies, coding problems, questions, scores, stats) is mocked in `src/data/` — no backend calls yet, structured so swapping in real API calls later is a drop-in change.
- The mic/camera "Record" button is a visual toggle only (no real getUserMedia capture), per the agreed scope.
- Coding round test results are deterministic mock pass/fail, not real code execution.
- Login is a demo auth flow — any email/password logs you in (or use "Continue as guest"). No real backend/session.

## Login

App now opens at `/login`. Enter any email/password (nothing is validated) or click "Continue as guest" to reach the dashboard. Logging out (bottom of the sidebar) sends you back to `/login`.

## Sample resume

A generated sample resume (`public/sample-resume.pdf`) is included for testing the Resume Upload screen:
- Click "Use sample resume" on the upload screen to skip picking a file, or
- Click "Download it to upload manually" to save the PDF and upload it through the real file picker/drag-and-drop for a more realistic demo.

## Structure

- `src/pages/` — one folder per practice mode (role, company, coding, hr), each with its own independent Interview/Feedback screens
- `src/components/` — shared UI: Sidebar, ReadinessRing, SkillRadarChart, StatsPanel, PracticeModeCard, RecordButton, StepProgress, etc.
- `src/data/` — all mock data plus a shared `generateFeedback.js` scoring helper

## Theme

Pastel palette defined as CSS variables in `src/index.css` (`@theme` block, Tailwind v4 style):
- Page `#FDFBD4`, Card `#F5F5DC`, Highlight `#D8BFD8`
- Accent `#9B7EBD`, plus rose `#D4A5A5` and sage `#A8C69F` for charts/tags
- Mode colors: Role `#D8BFD8`, Company `#F5D5AE`, Coding `#B8E0D2`, HR `#B5C7D3`
- Fonts: Fraunces (display/headings), Work Sans (body)
