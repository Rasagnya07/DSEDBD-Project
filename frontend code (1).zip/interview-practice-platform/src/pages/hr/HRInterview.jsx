import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { mockHRQuestions } from "../../data/mockHRQuestions";
import RecordButton from "../../components/RecordButton";
import StepProgress from "../../components/StepProgress";

export default function HRInterview() {
  const navigate = useNavigate();
  const [index, setIndex] = useState(0);
  const isLast = index === mockHRQuestions.length - 1;

  function next() {
    if (isLast) navigate("/practice/hr/feedback");
    else setIndex((i) => i + 1);
  }

  return (
    <div className="mx-auto max-w-2xl px-6 py-14">
      <p className="text-sm font-medium text-[var(--color-accent)]">HR / Behavioral Round</p>
      <div className="mt-3">
        <StepProgress current={index + 1} total={mockHRQuestions.length} />
        <p className="mt-2 text-xs text-[var(--color-ink-muted)]">
          Question {index + 1} of {mockHRQuestions.length}
        </p>
      </div>

      <div className="mt-8 rounded-2xl border border-[var(--color-border-soft)] bg-[var(--color-card)] p-8 text-center">
        <p className="font-[var(--font-display)] text-xl leading-snug text-[var(--color-ink)]">
          {mockHRQuestions[index]}
        </p>
      </div>

      <div className="mt-6 flex flex-col items-center gap-4">
        <RecordButton />
        <button
          onClick={next}
          className="rounded-full border border-[var(--color-border-soft)] px-5 py-2 text-sm text-[var(--color-ink-muted)] hover:text-[var(--color-ink)]"
        >
          {isLast ? "Finish & see feedback" : "Next question"}
        </button>
      </div>
    </div>
  );
}
