import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { mockHRQuestions } from "../../data/mockHRQuestions";
import { generateFeedback } from "../../data/generateFeedback";

export default function HRFeedback() {
  const navigate = useNavigate();
  const feedback = useMemo(() => generateFeedback(mockHRQuestions), []);

  return (
    <div className="mx-auto max-w-2xl px-6 py-14">
      <p className="text-sm font-medium text-[var(--color-accent)]">Feedback · HR Round</p>
      <h1 className="mt-1 font-[var(--font-display)] text-3xl text-[var(--color-ink)]">
        {feedback.overallScore}% overall
      </h1>

      <div className="mt-6 grid grid-cols-3 gap-3">
        {Object.entries(feedback.breakdown).map(([label, value]) => (
          <div key={label} className="rounded-xl border border-[var(--color-border-soft)] bg-[var(--color-card)] p-4 text-center">
            <p className="font-[var(--font-display)] text-xl text-[var(--color-ink)]">{value}%</p>
            <p className="mt-1 text-xs capitalize text-[var(--color-ink-muted)]">{label}</p>
          </div>
        ))}
      </div>

      <div className="mt-8 flex flex-col gap-4">
        {feedback.perQuestion.map((q, i) => (
          <div key={i} className="rounded-2xl border border-[var(--color-border-soft)] bg-[var(--color-card)] p-5">
            <div className="flex items-start justify-between gap-3">
              <p className="text-sm font-medium text-[var(--color-ink)]">{q.question}</p>
              <span className="shrink-0 rounded-full bg-[var(--color-mode-hr)] px-2.5 py-1 text-xs font-medium text-[var(--color-ink)]">
                {q.score}%
              </span>
            </div>
            <p className="mt-2 text-sm text-[var(--color-ink-muted)]">{q.feedback}</p>
          </div>
        ))}
      </div>

      <button
        onClick={() => navigate("/dashboard")}
        className="mt-8 w-full rounded-full bg-[var(--color-accent)] py-3 text-sm font-medium text-white"
      >
        Back to dashboard
      </button>
    </div>
  );
}
