import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search } from "lucide-react";
import { mockCompanies } from "../../data/mockCompanies";

export default function CompanySelect() {
  const [query, setQuery] = useState("");
  const navigate = useNavigate();
  const filtered = mockCompanies.filter((c) =>
    c.name.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="mx-auto max-w-2xl px-6 py-14">
      <p className="text-sm font-medium text-[var(--color-accent)]">Company-Based Practice</p>
      <h1 className="mt-1 font-[var(--font-display)] text-3xl text-[var(--color-ink)]">
        Pick a company
      </h1>
      <p className="mt-2 text-[var(--color-ink-muted)]">
        Practice questions styled after each company's known interview rounds.
      </p>

      <div className="mt-6 flex items-center gap-2 rounded-full border border-[var(--color-border-soft)] bg-[var(--color-card)] px-4 py-2.5">
        <Search size={16} className="text-[var(--color-ink-muted)]" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search companies"
          className="w-full bg-transparent text-sm text-[var(--color-ink)] outline-none placeholder:text-[var(--color-ink-muted)]"
        />
      </div>

      <div className="mt-6 flex flex-col gap-4">
        {filtered.map((c) => (
          <button
            key={c.id}
            onClick={() => navigate(`/practice/company/interview/${c.id}`)}
            className="flex items-center gap-4 rounded-2xl border border-[var(--color-border-soft)] bg-[var(--color-card)] p-5 text-left transition-transform hover:-translate-y-0.5"
          >
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[var(--color-mode-company)] font-[var(--font-display)] text-lg text-[var(--color-ink)]">
              {c.initial}
            </span>
            <div className="flex-1">
              <p className="font-[var(--font-display)] text-lg text-[var(--color-ink)]">{c.name}</p>
              <p className="text-sm text-[var(--color-ink-muted)]">
                {c.rounds.join(" · ")}
              </p>
              <p className="mt-1 text-xs text-[var(--color-ink-muted)]">
                Focus: {c.focusAreas.join(", ")} · Difficulty: {c.difficulty}
              </p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
