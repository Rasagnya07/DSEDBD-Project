import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { mockCompanies } from "../../data/mockCompanies";
import RecordButton from "../../components/RecordButton";
import StepProgress from "../../components/StepProgress";

export default function CompanyInterview() {
  const { companyId } = useParams();
  const navigate = useNavigate();
  const company = mockCompanies.find((c) => c.id === companyId);
  const [index, setIndex] = useState(0);

  if (!company) return null;
  const isLast = index === company.questions.length - 1;

  function next() {
    if (isLast) navigate(`/practice/company/feedback/${companyId}`);
    else setIndex((i) => i + 1);
  }

  return (
    <div className="mx-auto max-w-2xl px-6 py-14">
      <p className="text-sm font-medium text-[var(--color-accent)]">
        Mock Interview · {company.name}
      </p>
      <div className="mt-3">
        <StepProgress current={index + 1} total={company.questions.length} />
        <p className="mt-2 text-xs text-[var(--color-ink-muted)]">
          Question {index + 1} of {company.questions.length}
        </p>
      </div>

      <div className="mt-8 rounded-2xl border border-[var(--color-border-soft)] bg-[var(--color-card)] p-8 text-center">
        <p className="font-[var(--font-display)] text-xl leading-snug text-[var(--color-ink)]">
          {company.questions[index]}
        </p>
      </div>

      <div className="mt-6 flex flex-col items-center gap-4">
        <RecordButton />
        <button
          onClick={next}
          className="rounded-full border border-[var(--color-border-soft)] px-5 py-2 text-sm text-[var(--color-ink-muted)] hover:text-[var(--color-ink)]"
        >
          {isLast ? "Finish & see feedback" : "Next question"}
        </button>
      </div>
    </div>
  );
}
