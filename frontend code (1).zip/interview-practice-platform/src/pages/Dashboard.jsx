import { mockUser } from "../data/mockUser";
import { practiceModes } from "../data/mockModes";
import ReadinessRing from "../components/ReadinessRing";
import StreakBadge from "../components/StreakBadge";
import PracticeModeCard from "../components/PracticeModeCard";
import RecommendedCard from "../components/RecommendedCard";
import SkillRadarChart from "../components/SkillRadarChart";
import StatsPanel from "../components/StatsPanel";

export default function Dashboard() {
  return (
    <div className="mx-auto max-w-5xl px-6 py-10">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-[var(--font-display)] text-3xl text-[var(--color-ink)]">
            Welcome back, {mockUser.name}
          </h1>
          <p className="mt-1 text-[var(--color-ink-muted)]">
            Here's how your interview prep is going.
          </p>
        </div>
        <StreakBadge days={mockUser.streak} />
      </div>

      <div className="mt-8 rounded-2xl border border-[var(--color-border-soft)] bg-[var(--color-card)] p-6">
        <ReadinessRing score={mockUser.readinessScore} />
      </div>

      <div className="mt-8">
        <h2 className="mb-3 font-[var(--font-display)] text-xl text-[var(--color-ink)]">
          Choose how you want to practice
        </h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {practiceModes.map((mode) => (
            <PracticeModeCard key={mode.id} mode={mode} />
          ))}
        </div>
      </div>

      <div className="mt-6">
        <RecommendedCard recommendation={mockUser.recommendation} />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-5 lg:grid-cols-[1fr_1.4fr]">
        <SkillRadarChart data={mockUser.skillRadar} />
        <StatsPanel />
      </div>
    </div>
  );
}
