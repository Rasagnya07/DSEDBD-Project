import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Play } from "lucide-react";
import { mockCodingProblems } from "../../data/mockCodingProblems";

export default function CodingRound() {
  const { problemId } = useParams();
  const navigate = useNavigate();
  const problem = mockCodingProblems.find((p) => p.id === problemId);
  const [code, setCode] = useState(problem?.starterCode ?? "");
  const [running, setRunning] = useState(false);

  if (!problem) return null;

  function runTests() {
    setRunning(true);
    setTimeout(() => {
      navigate(`/practice/coding/results/${problemId}`, { state: { code } });
    }, 1200);
  }

  return (
    <div className="mx-auto max-w-4xl px-6 py-10">
      <p className="text-sm font-medium text-[var(--color-accent)]">Coding / Technical Round</p>
      <h1 className="mt-1 font-[var(--font-display)] text-3xl text-[var(--color-ink)]">
        {problem.title}
      </h1>

      <div className="mt-6 grid gap-5 md:grid-cols-2">
        <div className="rounded-2xl border border-[var(--color-border-soft)] bg-[var(--color-card)] p-5">
          <p className="text-sm font-medium text-[var(--color-ink)]">Problem</p>
          <p className="mt-2 text-sm leading-relaxed text-[var(--color-ink-muted)]">
            {problem.description}
          </p>
          <p className="mt-4 text-sm font-medium text-[var(--color-ink)]">Sample test cases</p>
          <div className="mt-2 flex flex-col gap-2">
            {problem.testCases.map((t, i) => (
              <div key={i} className="rounded-lg bg-[var(--color-page)] px-3 py-2 text-xs text-[var(--color-ink-muted)]">
                <span className="font-medium text-[var(--color-ink)]">Input:</span> {t.input}
                <br />
                <span className="font-medium text-[var(--color-ink)]">Expected:</span> {t.expected}
              </div>
            ))}
          </div>
        </div>

        <div className="flex flex-col rounded-2xl border border-[var(--color-border-soft)] bg-[var(--color-mode-coding)]/40 p-5">
          <p className="text-sm font-medium text-[var(--color-ink)]">Code editor</p>
          <textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            spellCheck={false}
            className="mt-2 h-64 flex-1 rounded-xl border border-[var(--color-border-soft)] bg-[var(--color-ink)] p-4 font-mono text-sm text-[var(--color-page)] outline-none"
          />
          <button
            onClick={runTests}
            disabled={running}
            className="mt-4 flex items-center justify-center gap-2 rounded-full bg-[var(--color-accent)] py-2.5 text-sm font-medium text-white disabled:opacity-50"
          >
            <Play size={16} />
            {running ? "Running test cases…" : "Run tests"}
          </button>
        </div>
      </div>
    </div>
  );
}
