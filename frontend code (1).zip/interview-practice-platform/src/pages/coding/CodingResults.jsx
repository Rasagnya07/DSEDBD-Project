import { useMemo } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { CheckCircle2, XCircle } from "lucide-react";
import { mockCodingProblems } from "../../data/mockCodingProblems";

export default function CodingResults() {
  const { problemId } = useParams();
  const navigate = useNavigate();
  const problem = mockCodingProblems.find((p) => p.id === problemId);

  const results = useMemo(() => {
    if (!problem) return null;
    return problem.testCases.map((t, i) => ({
      ...t,
      passed: i !== problem.testCases.length - 1, // mock: last case fails for realism
    }));
  }, [problem]);

  if (!problem || !results) return null;

  const passedCount = results.filter((r) => r.passed).length;
  const score = Math.round((passedCount / results.length) * 100);

  return (
    <div className="mx-auto max-w-2xl px-6 py-14">
      <p className="text-sm font-medium text-[var(--color-accent)]">
        Results · {problem.title}
      </p>
      <h1 className="mt-1 font-[var(--font-display)] text-3xl text-[var(--color-ink)]">
        {score}% test cases passed
      </h1>
      <p className="mt-2 text-[var(--color-ink-muted)]">
        {passedCount} of {results.length} passed · completed in 6m 40s (mock)
      </p>

      <div className="mt-8 flex flex-col gap-3">
        {results.map((r, i) => (
          <div
            key={i}
            className="flex items-center justify-between rounded-xl border border-[var(--color-border-soft)] bg-[var(--color-card)] px-4 py-3"
          >
            <div className="text-sm text-[var(--color-ink)]">
              <span className="font-medium">Input:</span> {r.input}
            </div>
            {r.passed ? (
              <span className="flex items-center gap-1 text-sm font-medium text-[var(--color-accent-sage)]">
                <CheckCircle2 size={16} /> Passed
              </span>
            ) : (
              <span className="flex items-center gap-1 text-sm font-medium text-[var(--color-accent-rose)]">
                <XCircle size={16} /> Failed
              </span>
            )}
          </div>
        ))}
      </div>

      <button
        onClick={() => navigate("/dashboard")}
        className="mt-8 w-full rounded-full bg-[var(--color-accent)] py-3 text-sm font-medium text-white"
      >
        Back to dashboard
      </button>
    </div>
  );
}
