import { useNavigate } from "react-router-dom";
import { mockCodingProblems } from "../../data/mockCodingProblems";

const DIFFICULTY_COLOR = {
  Easy: "var(--color-accent-sage)",
  Medium: "var(--color-accent-rose)",
  Hard: "var(--color-mode-hr)",
};

export default function ProblemList() {
  const navigate = useNavigate();

  return (
    <div className="mx-auto max-w-2xl px-6 py-14">
      <p className="text-sm font-medium text-[var(--color-accent)]">Coding / Technical Round</p>
      <h1 className="mt-1 font-[var(--font-display)] text-3xl text-[var(--color-ink)]">
        Pick a problem
      </h1>
      <p className="mt-2 text-[var(--color-ink-muted)]">
        Solve it in the editor, then see a mock score based on your test cases.
      </p>

      <div className="mt-8 flex flex-col gap-4">
        {mockCodingProblems.map((p) => (
          <button
            key={p.id}
            onClick={() => navigate(`/practice/coding/round/${p.id}`)}
            className="flex items-center justify-between gap-4 rounded-2xl border border-[var(--color-border-soft)] bg-[var(--color-card)] p-5 text-left transition-transform hover:-translate-y-0.5"
          >
            <div>
              <p className="font-[var(--font-display)] text-lg text-[var(--color-ink)]">{p.title}</p>
              <p className="mt-1 text-sm text-[var(--color-ink-muted)]">
                {p.testCases.length} test cases
              </p>
            </div>
            <span
              className="rounded-full px-3 py-1 text-xs font-medium text-[var(--color-ink)]"
              style={{ backgroundColor: DIFFICULTY_COLOR[p.difficulty] }}
            >
              {p.difficulty}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}
