import { useNavigate } from "react-router-dom";
import { CheckCircle2, XCircle } from "lucide-react";
import { mockJobs } from "../../data/mockJobs";

export default function MatchResults() {
  const navigate = useNavigate();

  return (
    <div className="mx-auto max-w-2xl px-6 py-14">
      <p className="text-sm font-medium text-[var(--color-accent)]">Role-Based Practice</p>
      <h1 className="mt-1 font-[var(--font-display)] text-3xl text-[var(--color-ink)]">
        Your top matches
      </h1>
      <p className="mt-2 text-[var(--color-ink-muted)]">
        Ranked by fit with your resume. Pick one to start a mock interview.
      </p>

      <div className="mt-8 flex flex-col gap-4">
        {mockJobs.map((job) => (
          <div
            key={job.id}
            className="rounded-2xl border border-[var(--color-border-soft)] bg-[var(--color-card)] p-5"
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="font-[var(--font-display)] text-lg text-[var(--color-ink)]">
                  {job.title}
                </p>
                <p className="text-sm text-[var(--color-ink-muted)]">{job.company}</p>
              </div>
              <span className="rounded-full bg-[var(--color-mode-role)] px-3 py-1 text-sm font-medium text-[var(--color-ink)]">
                {job.matchScore}% match
              </span>
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              {job.matchedSkills.map((s) => (
                <span
                  key={s}
                  className="flex items-center gap-1 rounded-full bg-[var(--color-accent-sage)]/30 px-2.5 py-1 text-xs text-[var(--color-ink)]"
                >
                  <CheckCircle2 size={12} /> {s}
                </span>
              ))}
              {job.missingSkills.map((s) => (
                <span
                  key={s}
                  className="flex items-center gap-1 rounded-full bg-[var(--color-accent-rose)]/30 px-2.5 py-1 text-xs text-[var(--color-ink)]"
                >
                  <XCircle size={12} /> {s}
                </span>
              ))}
            </div>

            <button
              onClick={() => navigate(`/practice/role/interview/${job.id}`)}
              className="mt-4 w-full rounded-full bg-[var(--color-accent)] py-2.5 text-sm font-medium text-white"
            >
              Start mock interview
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
