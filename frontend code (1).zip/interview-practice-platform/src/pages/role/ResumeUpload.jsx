import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { UploadCloud, FileText } from "lucide-react";

export default function ResumeUpload() {
  const [fileName, setFileName] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const navigate = useNavigate();

  function handleFile(file) {
    if (!file) return;
    setFileName(file.name);
  }

  function startAnalysis() {
    setAnalyzing(true);
    setTimeout(() => navigate("/practice/role/matches"), 1400);
  }

  return (
    <div className="mx-auto max-w-2xl px-6 py-14">
      <p className="text-sm font-medium text-[var(--color-accent)]">Role-Based Practice</p>
      <h1 className="mt-1 font-[var(--font-display)] text-3xl text-[var(--color-ink)]">
        Upload your resume
      </h1>
      <p className="mt-2 text-[var(--color-ink-muted)]">
        We'll match you to roles based on your skills and experience.
      </p>

      <label
        className="mt-8 flex cursor-pointer flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-[var(--color-mode-role)] bg-[var(--color-card)] px-6 py-14 text-center"
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => {
          e.preventDefault();
          handleFile(e.dataTransfer.files?.[0]);
        }}
      >
        <input
          type="file"
          accept=".pdf,.doc,.docx"
          className="hidden"
          onChange={(e) => handleFile(e.target.files?.[0])}
        />
        {fileName ? (
          <>
            <FileText size={32} className="text-[var(--color-accent)]" />
            <p className="text-sm font-medium text-[var(--color-ink)]">{fileName}</p>
            <p className="text-xs text-[var(--color-ink-muted)]">Click to choose a different file</p>
          </>
        ) : (
          <>
            <UploadCloud size={32} className="text-[var(--color-accent)]" />
            <p className="text-sm font-medium text-[var(--color-ink)]">
              Drag and drop your resume, or click to browse
            </p>
            <p className="text-xs text-[var(--color-ink-muted)]">PDF or Word, up to 5MB</p>
          </>
        )}
      </label>

      <div className="mt-4 text-center text-sm text-[var(--color-ink-muted)]">or</div>

      <textarea
        placeholder="Paste your resume text instead"
        className="mt-4 h-24 w-full rounded-xl border border-[var(--color-border-soft)] bg-[var(--color-card)] p-3 text-sm text-[var(--color-ink)] outline-none placeholder:text-[var(--color-ink-muted)]"
        onChange={(e) => e.target.value && setFileName("Pasted resume text")}
      />

      <button
        disabled={!fileName || analyzing}
        onClick={startAnalysis}
        className="mt-6 w-full rounded-full bg-[var(--color-accent)] py-3 text-sm font-medium text-white transition-opacity disabled:opacity-40"
      >
        {analyzing ? "Analyzing your resume…" : "Find matching roles"}
      </button>

      <div className="mt-3 flex items-center justify-center gap-3 text-xs text-[var(--color-ink-muted)]">
        <button
          onClick={() => setFileName("sample-resume.pdf")}
          className="underline decoration-dotted underline-offset-2 hover:text-[var(--color-ink)]"
        >
          Use sample resume
        </button>
        <span>·</span>
        <a
          href="/sample-resume.pdf"
          download
          className="underline decoration-dotted underline-offset-2 hover:text-[var(--color-ink)]"
        >
          Download it to upload manually
        </a>
      </div>
    </div>
  );
}
