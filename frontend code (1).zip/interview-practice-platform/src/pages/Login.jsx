import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { LogIn } from "lucide-react";
import { useAuth } from "../auth/AuthContext";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  const { login } = useAuth();

  function handleSubmit(e) {
    e.preventDefault();
    login(email || "rasagnya@example.com");
    navigate("/dashboard");
  }

  function continueAsGuest() {
    login("Guest");
    navigate("/dashboard");
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-[var(--color-page)] px-6">
      <div className="w-full max-w-sm rounded-2xl border border-[var(--color-border-soft)] bg-[var(--color-card)] p-8">
        <p className="font-[var(--font-display)] text-2xl text-[var(--color-ink)]">
          Interview Practice
        </p>
        <p className="mt-1 text-sm text-[var(--color-ink-muted)]">
          Sign in to continue your prep.
        </p>

        <form onSubmit={handleSubmit} className="mt-6 flex flex-col gap-4">
          <div>
            <label className="text-xs font-medium text-[var(--color-ink-muted)]">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="mt-1 w-full rounded-xl border border-[var(--color-border-soft)] bg-[var(--color-page)] px-3 py-2.5 text-sm text-[var(--color-ink)] outline-none placeholder:text-[var(--color-ink-muted)]"
            />
          </div>
          <div>
            <label className="text-xs font-medium text-[var(--color-ink-muted)]">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="mt-1 w-full rounded-xl border border-[var(--color-border-soft)] bg-[var(--color-page)] px-3 py-2.5 text-sm text-[var(--color-ink)] outline-none placeholder:text-[var(--color-ink-muted)]"
            />
          </div>

          <button
            type="submit"
            className="mt-2 flex items-center justify-center gap-2 rounded-full bg-[var(--color-accent)] py-2.5 text-sm font-medium text-white transition-opacity hover:opacity-90"
          >
            <LogIn size={16} />
            Log in
          </button>
        </form>

        <div className="my-4 flex items-center gap-3 text-xs text-[var(--color-ink-muted)]">
          <span className="h-px flex-1 bg-[var(--color-border-soft)]" />
          or
          <span className="h-px flex-1 bg-[var(--color-border-soft)]" />
        </div>

        <button
          onClick={continueAsGuest}
          className="w-full rounded-full border border-[var(--color-border-soft)] py-2.5 text-sm font-medium text-[var(--color-ink)] hover:bg-[var(--color-highlight)]/40"
        >
          Continue as guest
        </button>

        <p className="mt-4 text-center text-xs text-[var(--color-ink-muted)]">
          This is a demo login — any email/password works.
        </p>
      </div>
    </div>
  );
}
