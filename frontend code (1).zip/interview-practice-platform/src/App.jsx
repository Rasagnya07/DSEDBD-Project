import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./auth/AuthContext";
import RequireAuth from "./auth/RequireAuth";
import Sidebar from "./components/Sidebar";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";

import ResumeUpload from "./pages/role/ResumeUpload";
import MatchResults from "./pages/role/MatchResults";
import RoleInterview from "./pages/role/RoleInterview";
import RoleFeedback from "./pages/role/RoleFeedback";

import CompanySelect from "./pages/company/CompanySelect";
import CompanyInterview from "./pages/company/CompanyInterview";
import CompanyFeedback from "./pages/company/CompanyFeedback";

import ProblemList from "./pages/coding/ProblemList";
import CodingRound from "./pages/coding/CodingRound";
import CodingResults from "./pages/coding/CodingResults";

import HRInterview from "./pages/hr/HRInterview";
import HRFeedback from "./pages/hr/HRFeedback";

function AppShell({ children }) {
  return (
    <div className="flex min-h-screen bg-[var(--color-page)]">
      <Sidebar />
      <main className="flex-1">{children}</main>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<Navigate to="/login" replace />} />

          <Route
            path="/dashboard"
            element={
              <RequireAuth>
                <AppShell><Dashboard /></AppShell>
              </RequireAuth>
            }
          />

          <Route
            path="/practice/role"
            element={<RequireAuth><AppShell><ResumeUpload /></AppShell></RequireAuth>}
          />
          <Route
            path="/practice/role/matches"
            element={<RequireAuth><AppShell><MatchResults /></AppShell></RequireAuth>}
          />
          <Route
            path="/practice/role/interview/:jobId"
            element={<RequireAuth><AppShell><RoleInterview /></AppShell></RequireAuth>}
          />
          <Route
            path="/practice/role/feedback/:jobId"
            element={<RequireAuth><AppShell><RoleFeedback /></AppShell></RequireAuth>}
          />

          <Route
            path="/practice/company"
            element={<RequireAuth><AppShell><CompanySelect /></AppShell></RequireAuth>}
          />
          <Route
            path="/practice/company/interview/:companyId"
            element={<RequireAuth><AppShell><CompanyInterview /></AppShell></RequireAuth>}
          />
          <Route
            path="/practice/company/feedback/:companyId"
            element={<RequireAuth><AppShell><CompanyFeedback /></AppShell></RequireAuth>}
          />

          <Route
            path="/practice/coding"
            element={<RequireAuth><AppShell><ProblemList /></AppShell></RequireAuth>}
          />
          <Route
            path="/practice/coding/round/:problemId"
            element={<RequireAuth><AppShell><CodingRound /></AppShell></RequireAuth>}
          />
          <Route
            path="/practice/coding/results/:problemId"
            element={<RequireAuth><AppShell><CodingResults /></AppShell></RequireAuth>}
          />

          <Route
            path="/practice/hr"
            element={<RequireAuth><AppShell><HRInterview /></AppShell></RequireAuth>}
          />
          <Route
            path="/practice/hr/feedback"
            element={<RequireAuth><AppShell><HRFeedback /></AppShell></RequireAuth>}
          />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
