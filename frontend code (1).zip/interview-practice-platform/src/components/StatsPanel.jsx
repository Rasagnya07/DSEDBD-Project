import { useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from "recharts";
import { mockStats } from "../data/mockStats";

export default function StatsPanel() {
  const [range, setRange] = useState("weekly");
  const stats = mockStats[range];

  return (
    <div className="rounded-2xl border border-[var(--color-border-soft)] bg-[var(--color-card)] p-5">
      <div className="flex items-center justify-between">
        <p className="font-[var(--font-display)] text-lg text-[var(--color-ink)]">Your progress</p>
        <div className="flex rounded-full border border-[var(--color-border-soft)] p-1 text-sm">
          {["weekly", "monthly"].map((r) => (
            <button
              key={r}
              onClick={() => setRange(r)}
              className={`rounded-full px-3 py-1 capitalize transition-colors ${
                range === r
                  ? "bg-[var(--color-highlight)] text-[var(--color-ink)]"
                  : "text-[var(--color-ink-muted)]"
              }`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatBox label="Sessions" value={stats.totalSessions} />
        <StatBox label="Avg score" value={`${stats.avgScore}%`} />
        <StatBox label="Most practiced" value={stats.mostPracticed} small />
        <StatBox label="Improvement" value={`+${stats.improvement}%`} accent />
      </div>

      <div className="mt-5 grid gap-5 md:grid-cols-2">
        <div>
          <p className="mb-2 text-sm text-[var(--color-ink-muted)]">Score trend</p>
          <div className="h-40">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={stats.scoreTrend}>
                <CartesianGrid stroke="var(--color-border-soft)" vertical={false} />
                <XAxis dataKey="label" tick={{ fontSize: 11, fill: "var(--color-ink-muted)" }} axisLine={false} tickLine={false} />
                <YAxis hide domain={[40, 100]} />
                <Tooltip />
                <Line type="monotone" dataKey="value" stroke="var(--color-accent)" strokeWidth={2.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div>
          <p className="mb-2 text-sm text-[var(--color-ink-muted)]">Sessions by mode</p>
          <div className="h-40">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.modeBreakdown}>
                <CartesianGrid stroke="var(--color-border-soft)" vertical={false} />
                <XAxis dataKey="mode" tick={{ fontSize: 11, fill: "var(--color-ink-muted)" }} axisLine={false} tickLine={false} />
                <YAxis hide />
                <Tooltip />
                <Bar dataKey="sessions" fill="var(--color-accent-rose)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatBox({ label, value, accent, small }) {
  return (
    <div className="rounded-xl bg-[var(--color-page)] px-3 py-2.5">
      <p className="text-xs text-[var(--color-ink-muted)]">{label}</p>
      <p
        className={`font-[var(--font-display)] ${small ? "text-base" : "text-xl"} ${
          accent ? "text-[var(--color-accent-sage)]" : "text-[var(--color-ink)]"
        }`}
      >
        {value}
      </p>
    </div>
  );
}
