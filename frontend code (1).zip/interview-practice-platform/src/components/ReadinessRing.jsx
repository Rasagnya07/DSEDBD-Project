export default function ReadinessRing({ score }) {
  const radius = 52;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;

  return (
    <div className="flex items-center gap-6">
      <div className="relative w-32 h-32 shrink-0">
        <svg width="128" height="128" viewBox="0 0 128 128" className="-rotate-90">
          <circle cx="64" cy="64" r={radius} fill="none" stroke="var(--color-border-soft)" strokeWidth="12" />
          <circle
            cx="64"
            cy="64"
            r={radius}
            fill="none"
            stroke="var(--color-accent)"
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="font-[var(--font-display)] text-2xl text-[var(--color-ink)]">
            {score}%
          </span>
        </div>
      </div>
      <div>
        <p className="text-sm font-medium text-[var(--color-ink)]">Interview readiness</p>
        <p className="text-sm text-[var(--color-ink-muted)]">Based on your last 14 sessions</p>
      </div>
    </div>
  );
}
