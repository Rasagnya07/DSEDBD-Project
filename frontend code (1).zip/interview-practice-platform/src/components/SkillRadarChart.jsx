import {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ResponsiveContainer,
} from "recharts";

export default function SkillRadarChart({ data }) {
  return (
    <div className="rounded-2xl border border-[var(--color-border-soft)] bg-[var(--color-card)] p-5">
      <p className="font-[var(--font-display)] text-lg text-[var(--color-ink)]">Skill breakdown</p>
      <p className="text-sm text-[var(--color-ink-muted)]">Averaged across your recent sessions</p>
      <div className="mt-2 h-64">
        <ResponsiveContainer width="100%" height="100%">
          <RadarChart data={data} outerRadius="75%">
            <PolarGrid stroke="var(--color-border-soft)" />
            <PolarAngleAxis
              dataKey="skill"
              tick={{ fill: "var(--color-ink-muted)", fontSize: 12 }}
            />
            <PolarRadiusAxis angle={90} domain={[0, 100]} tick={false} axisLine={false} />
            <Radar
              dataKey="value"
              stroke="var(--color-accent)"
              fill="var(--color-accent)"
              fillOpacity={0.35}
            />
          </RadarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
