import { NavLink, useNavigate } from "react-router-dom";
import { LayoutGrid, Target, Building2, Code2, MessagesSquare, LogOut } from "lucide-react";
import { useAuth } from "../auth/AuthContext";

const links = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutGrid },
  { to: "/practice/role", label: "Role-Based", icon: Target },
  { to: "/practice/company", label: "Company-Based", icon: Building2 },
  { to: "/practice/coding", label: "Coding Round", icon: Code2 },
  { to: "/practice/hr", label: "HR Round", icon: MessagesSquare },
];

export default function Sidebar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  function handleLogout() {
    logout();
    navigate("/login");
  }

  return (
    <aside className="hidden md:flex md:flex-col w-60 shrink-0 border-r border-[var(--color-border-soft)] bg-[var(--color-card)] px-5 py-7">
      <div className="mb-10 px-1">
        <p className="font-[var(--font-display)] text-[1.35rem] leading-tight text-[var(--color-ink)]">
          Interview<br />Practice
        </p>
      </div>
      <nav className="flex flex-col gap-1">
        {links.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors ${
                isActive
                  ? "bg-[var(--color-highlight)] text-[var(--color-ink)] font-medium"
                  : "text-[var(--color-ink-muted)] hover:bg-[var(--color-highlight)]/50 hover:text-[var(--color-ink)]"
              }`
            }
          >
            <Icon size={18} strokeWidth={2} />
            {label}
          </NavLink>
        ))}
      </nav>

      <div className="mt-auto flex items-center justify-between gap-2 border-t border-[var(--color-border-soft)] pt-4">
        <p className="truncate text-xs text-[var(--color-ink-muted)]">{user?.identifier}</p>
        <button
          onClick={handleLogout}
          className="flex items-center gap-1 rounded-full px-2 py-1 text-xs text-[var(--color-ink-muted)] hover:text-[var(--color-ink)]"
        >
          <LogOut size={14} />
          Log out
        </button>
      </div>
    </aside>
  );
}
