import { useState } from "react";
import { Mic, Square } from "lucide-react";

export default function RecordButton({ onStop }) {
  const [recording, setRecording] = useState(false);

  function toggle() {
    if (recording) {
      setRecording(false);
      onStop?.();
    } else {
      setRecording(true);
    }
  }

  return (
    <button
      onClick={toggle}
      className={`flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-medium transition-colors ${
        recording
          ? "bg-[var(--color-accent-rose)] text-[var(--color-ink)]"
          : "bg-[var(--color-accent)] text-white"
      }`}
    >
      {recording ? <Square size={16} /> : <Mic size={16} />}
      {recording ? "Recording… tap to stop" : "Tap to answer"}
    </button>
  );
}
