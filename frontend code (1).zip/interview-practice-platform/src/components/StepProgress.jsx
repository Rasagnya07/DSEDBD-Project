export default function StepProgress({ current, total }) {
  return (
    <div className="flex items-center gap-2">
      {Array.from({ length: total }).map((_, i) => (
        <span
          key={i}
          className={`h-1.5 flex-1 rounded-full ${
            i < current ? "bg-[var(--color-accent)]" : "bg-[var(--color-border-soft)]"
          }`}
        />
      ))}
    </div>
  );
}
