import { Flame } from "lucide-react";

export default function StreakBadge({ days }) {
  return (
    <div className="inline-flex items-center gap-1.5 rounded-full bg-[var(--color-accent-rose)]/40 px-3 py-1.5 text-sm font-medium text-[var(--color-ink)]">
      <Flame size={16} className="text-[var(--color-accent)]" />
      {days}-day streak
    </div>
  );
}
