import { useNavigate } from "react-router-dom";
import { Target, Building2, Code2, MessagesSquare, ArrowUpRight } from "lucide-react";

const ICONS = {
  target: Target,
  building: Building2,
  code: Code2,
  chat: MessagesSquare,
};

export default function PracticeModeCard({ mode }) {
  const navigate = useNavigate();
  const Icon = ICONS[mode.icon];

  return (
    <button
      onClick={() => navigate(mode.path)}
      className="group flex flex-col items-start gap-4 rounded-2xl border border-[var(--color-border-soft)] p-5 text-left transition-transform hover:-translate-y-0.5"
      style={{ backgroundColor: mode.color }}
    >
      <div className="flex w-full items-start justify-between">
        <span className="flex h-10 w-10 items-center justify-center rounded-full bg-white/50">
          <Icon size={20} className="text-[var(--color-ink)]" />
        </span>
        <ArrowUpRight
          size={18}
          className="text-[var(--color-ink)] opacity-0 transition-opacity group-hover:opacity-70"
        />
      </div>
      <div>
        <p className="font-[var(--font-display)] text-lg text-[var(--color-ink)]">
          {mode.title}
        </p>
        <p className="mt-1.5 text-sm leading-snug text-[var(--color-ink)]/80">
          {mode.blurb}
        </p>
      </div>
    </button>
  );
}
