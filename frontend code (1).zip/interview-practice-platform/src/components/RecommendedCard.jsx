import { useNavigate } from "react-router-dom";
import { Sparkles } from "lucide-react";
import { practiceModes } from "../data/mockModes";

export default function RecommendedCard({ recommendation }) {
  const navigate = useNavigate();
  const mode = practiceModes.find((m) => m.id === recommendation.modeId);

  return (
    <div className="flex items-center justify-between gap-4 rounded-2xl border border-[var(--color-border-soft)] bg-[var(--color-card)] p-5">
      <div className="flex items-start gap-3">
        <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[var(--color-accent)]/20">
          <Sparkles size={16} className="text-[var(--color-accent)]" />
        </span>
        <div>
          <p className="text-sm font-medium text-[var(--color-ink)]">Recommended for you</p>
          <p className="text-sm text-[var(--color-ink-muted)]">{recommendation.reason}</p>
        </div>
      </div>
      <button
        onClick={() => mode && navigate(mode.path)}
        className="shrink-0 rounded-full bg-[var(--color-accent)] px-4 py-2 text-sm font-medium text-white transition-opacity hover:opacity-90"
      >
        {recommendation.ctaLabel}
      </button>
    </div>
  );
}
