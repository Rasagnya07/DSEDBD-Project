export const mockHRQuestions = [
  "Tell me about yourself.",
  "What are your greatest strengths and weaknesses?",
  "Describe a time you faced conflict with a teammate and how you resolved it.",
  "Why should we hire you over other candidates?",
  "Where do you see yourself in five years?",
  "Tell me about a time you failed and what you learned from it.",
];
