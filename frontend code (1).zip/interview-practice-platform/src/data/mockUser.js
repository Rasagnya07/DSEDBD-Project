export const mockUser = {
  name: "Rasagnya",
  streak: 3,
  readinessScore: 72,
  sessionsCompleted: 14,
  avgScore: 78,
  skillRadar: [
    { skill: "Content", value: 80 },
    { skill: "Delivery", value: 68 },
    { skill: "Pacing", value: 62 },
    { skill: "Technical", value: 74 },
    { skill: "Confidence", value: 70 },
  ],
  recommendation: {
    reason: "Your coding round scores dipped this week",
    modeId: "coding",
    ctaLabel: "Practice a coding round",
  },
};
