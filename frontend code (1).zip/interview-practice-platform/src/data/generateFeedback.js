// Deterministic-ish mock feedback generator so every run of the demo
// feels populated without wiring up a real scoring backend yet.
const REMARKS = [
  "Clear structure, led with the outcome first.",
  "Good specifics, but the answer ran a little long.",
  "Confident delivery — watch filler words like 'um' and 'like'.",
  "Strong technical grounding, could tighten the explanation.",
  "Nice use of a concrete example to back up the claim.",
];

function seededScore(seed, min = 60, max = 92) {
  const hash = Array.from(seed).reduce((acc, c) => acc + c.charCodeAt(0), 0);
  return min + (hash % (max - min));
}

export function generateFeedback(questions) {
  const perQuestion = questions.map((q, i) => ({
    question: q,
    score: seededScore(q + i, 62, 95),
    feedback: REMARKS[i % REMARKS.length],
  }));

  const avg = Math.round(
    perQuestion.reduce((sum, q) => sum + q.score, 0) / perQuestion.length
  );

  return {
    overallScore: avg,
    breakdown: {
      content: Math.min(97, avg + 4),
      delivery: Math.max(50, avg - 6),
      pacing: Math.max(50, avg - 10),
    },
    perQuestion,
  };
}
