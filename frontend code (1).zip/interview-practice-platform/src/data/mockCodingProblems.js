export const mockCodingProblems = [
  {
    id: "two-sum",
    title: "Two Sum",
    difficulty: "Easy",
    description:
      "Given an array of integers and a target, return the indices of the two numbers that add up to the target. Assume exactly one solution exists.",
    starterCode: `function twoSum(nums, target) {
  // your code here
}`,
    testCases: [
      { input: "[2,7,11,15], target=9", expected: "[0,1]" },
      { input: "[3,2,4], target=6", expected: "[1,2]" },
      { input: "[3,3], target=6", expected: "[0,1]" },
    ],
  },
  {
    id: "valid-parens",
    title: "Valid Parentheses",
    difficulty: "Easy",
    description:
      "Given a string containing just '(', ')', '{', '}', '[' and ']', determine if the input string is valid (brackets close in the correct order).",
    starterCode: `function isValid(s) {
  // your code here
}`,
    testCases: [
      { input: '"()"', expected: "true" },
      { input: '"()[]{}"', expected: "true" },
      { input: '"(]"', expected: "false" },
    ],
  },
  {
    id: "longest-substring",
    title: "Longest Substring Without Repeating Characters",
    difficulty: "Medium",
    description:
      "Given a string, find the length of the longest substring without repeating characters.",
    starterCode: `function lengthOfLongestSubstring(s) {
  // your code here
}`,
    testCases: [
      { input: '"abcabcbb"', expected: "3" },
      { input: '"bbbbb"', expected: "1" },
      { input: '"pwwkew"', expected: "3" },
    ],
  },
];
