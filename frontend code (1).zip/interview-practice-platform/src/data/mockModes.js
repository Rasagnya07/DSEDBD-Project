export const practiceModes = [
  {
    id: "role",
    title: "Role-Based Practice",
    blurb: "Upload your resume and get matched with roles, then practice questions tailored to that job.",
    color: "var(--color-mode-role)",
    path: "/practice/role",
    icon: "target",
  },
  {
    id: "company",
    title: "Company-Based Practice",
    blurb: "Pick a company and rehearse the rounds and question styles they're known for.",
    color: "var(--color-mode-company)",
    path: "/practice/company",
    icon: "building",
  },
  {
    id: "coding",
    title: "Coding / Technical Round",
    blurb: "Solve timed problems in a mock editor and see how you'd score on a technical round.",
    color: "var(--color-mode-coding)",
    path: "/practice/coding",
    icon: "code",
  },
  {
    id: "hr",
    title: "HR / Behavioral Round",
    blurb: "Practice the behavioral questions every interview opens with — and close with confidence.",
    color: "var(--color-mode-hr)",
    path: "/practice/hr",
    icon: "chat",
  },
];
