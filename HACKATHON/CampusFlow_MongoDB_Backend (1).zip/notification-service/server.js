require('dotenv').config({path:require('path').resolve(__dirname,'../.env')});
const express=require('express'),cors=require('cors');const connectDB=require('../shared/db');
const {Notification,ServiceRequest}=require('../shared/models');const {getChannel}=require('../shared/events');
const {authenticate}=require('../shared/auth');const errors=require('../shared/errors');
const app=express();app.use(cors());app.use(express.json());
app.get('/health',(req,res)=>res.json({service:'notification-service',status:'ok'}));
app.get('/notifications',authenticate,async(req,res,next)=>{try{res.json(await Notification.find({user:req.user.user_id}).sort({createdAt:-1}).limit(100))}catch(e){next(e)}});
app.patch('/notifications/:id/read',authenticate,async(req,res,next)=>{
 try{const n=await Notification.findOneAndUpdate({_id:req.params.id,user:req.user.user_id},{isRead:true},{new:true});if(!n)return res.status(404).json({message:'Notification not found'});res.json(n)}catch(e){next(e)}
});
async function consume(){
 const ch=await getChannel();if(!ch){console.warn('RabbitMQ consumer unavailable');return}
 await ch.assertQueue('campusflow.notifications',{durable:true});
 await ch.bindQueue('campusflow.notifications','campusflow.events','request.*');
 ch.consume('campusflow.notifications',async msg=>{
  if(!msg)return;
  try{
   const e=JSON.parse(msg.content.toString());let recipient=e.user_id;let text='Your campus request has an update.';
   if(msg.fields.routingKey==='request.created')text=`Your request #${e.request_id} was submitted successfully.`;
   if(msg.fields.routingKey==='request.status_changed')text=`Request #${e.request_id} status changed to ${e.status}.`;
   if(msg.fields.routingKey==='request.assigned'){
    const req=await ServiceRequest.findById(e.request_id);
    if(req)await Notification.create({user:req.requester,message:`Request #${e.request_id} has been assigned to staff.`,eventType:'request.assigned'});
    await Notification.create({user:e.staff_id,message:`You have been assigned request #${e.request_id}.`,eventType:'request.assigned'});
   }else if(recipient){await Notification.create({user:recipient,message:text,eventType:msg.fields.routingKey})}
   ch.ack(msg);
  }catch(err){console.error('Notification event failed',err);ch.nack(msg,false,false)}
 });
 console.log('Notification service consuming request.* events');
}
app.use(errors);
connectDB().then(()=>{app.listen(5004,()=>console.log('Notification service on 5004'));consume()}).catch(e=>{console.error(e);process.exit(1)});
