require('dotenv').config({path:require('path').resolve(__dirname,'../.env')});
const express=require('express'),cors=require('cors');const connectDB=require('../shared/db');
const {Department,Assignment,ServiceRequest,User,RequestUpdate,Feedback}=require('../shared/models');
const {authenticate,allowRoles}=require('../shared/auth');const {publishEvent}=require('../shared/events');const errors=require('../shared/errors');
const app=express();app.use(cors());app.use(express.json());
app.get('/health',(req,res)=>res.json({service:'assignment-service',status:'ok'}));
app.get('/departments',authenticate,async(req,res,next)=>{try{res.json(await Department.find())}catch(e){next(e)}});
app.get('/assignments',authenticate,async(req,res,next)=>{
 try{const filter=req.user.role==='Staff'?{staff:req.user.user_id,active:true}:{};
 res.json(await Assignment.find(filter).sort({assignedAt:-1}).populate('request').populate('staff','name email').populate('assignedBy','name'))}catch(e){next(e)}
});
app.post('/assignments',authenticate,allowRoles('Admin'),async(req,res,next)=>{
 try{const{requestId,staffId}=req.body;if(!requestId||!staffId)return res.status(400).json({message:'requestId and staffId are required'});
 const [request,staff]=await Promise.all([ServiceRequest.findById(requestId).populate({path:'category',populate:{path:'department'}}),User.findById(staffId).populate('department')]);
 if(!request)return res.status(404).json({message:'Request not found'});
 if(!staff||staff.role!=='Staff')return res.status(400).json({message:'Selected user is not a staff member'});
 if(String(staff.department?._id)!==String(request.category.department._id))return res.status(400).json({message:'Staff member does not belong to the request department'});
 await Assignment.updateMany({request:request._id,active:true},{active:false});
 const assignment=await Assignment.create({request:request._id,staff:staff._id,assignedBy:req.user.user_id});
 const oldStatus=request.status;request.status='Assigned';await request.save();
 await RequestUpdate.create({request:request._id,updatedBy:req.user.user_id,oldStatus,newStatus:'Assigned',remarks:'Assigned to staff member'});
 await publishEvent('request.assigned',{request_id:String(request._id),staff_id:String(staff._id),requester_id:String(request.requester)});
 res.status(201).json({message:'Request assigned successfully',assignment});
 }catch(e){next(e)}
});
app.get('/staff/workload',authenticate,allowRoles('Admin','Management'),async(req,res,next)=>{
 try{const staff=await User.find({role:'Staff'}).select('name email department').populate('department','name');
 const result=await Promise.all(staff.map(async s=>({staff:s,activeAssignments:await Assignment.countDocuments({staff:s._id,active:true})})));
 result.sort((a,b)=>a.activeAssignments-b.activeAssignments);res.json(result);
 }catch(e){next(e)}
});
app.get('/analytics/dashboard',authenticate,allowRoles('Admin','Management'),async(req,res,next)=>{
 try{
  const [totalRequests,openRequests,resolvedRequests,slaBreached,byStatus,byCategory,byDepartment,feedback]=await Promise.all([
   ServiceRequest.countDocuments(),
   ServiceRequest.countDocuments({status:{$in:['Submitted','Assigned','In Progress','On Hold']}}),
   ServiceRequest.countDocuments({status:{$in:['Resolved','Closed']}}),
   ServiceRequest.countDocuments({slaDeadline:{$lt:new Date()},status:{$nin:['Resolved','Closed','Rejected']}}),
   ServiceRequest.aggregate([{$group:{_id:'$status',count:{$sum:1}}}]),
   ServiceRequest.aggregate([{$group:{_id:'$category',count:{$sum:1}}},{$lookup:{from:'categories',localField:'_id',foreignField:'_id',as:'category'}},{$unwind:'$category'},{$project:{_id:0,category:'$category.name',count:1}}]),
   ServiceRequest.aggregate([{$lookup:{from:'categories',localField:'category',foreignField:'_id',as:'cat'}},{$unwind:'$cat'},{$lookup:{from:'departments',localField:'cat.department',foreignField:'_id',as:'dept'}},{$unwind:'$dept'},{$group:{_id:'$dept.name',count:{$sum:1}}}]),
   Feedback.aggregate([{$group:{_id:null,averageRating:{$avg:'$rating'},count:{$sum:1}}}])
  ]);
  res.json({totals:{totalRequests,openRequests,resolvedRequests,slaBreached},byStatus,byCategory,byDepartment,feedback:feedback[0]||{averageRating:null,count:0}});
 }catch(e){next(e)}
});
app.use(errors);connectDB().then(()=>app.listen(5003,()=>console.log('Assignment service on 5003'))).catch(e=>{console.error(e);process.exit(1)});
