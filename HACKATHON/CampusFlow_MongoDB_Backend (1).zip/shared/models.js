const mongoose = require('mongoose');
const { Schema } = mongoose;
const opts = { timestamps: true };

const User = mongoose.model('User', new Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true, index: true },
  passwordHash: { type: String, required: true },
  role: { type: String, enum: ['Student','Faculty','Staff','Admin','Management'], default: 'Student', index: true },
  department: { type: Schema.Types.ObjectId, ref: 'Department', default: null }
}, opts));

const Department = mongoose.model('Department', new Schema({
  name: { type: String, required: true, unique: true, trim: true }
}, opts));

const Category = mongoose.model('Category', new Schema({
  name: { type: String, required: true, unique: true, trim: true },
  department: { type: Schema.Types.ObjectId, ref: 'Department', required: true }
}, opts));

const Location = mongoose.model('Location', new Schema({
  building: { type: String, required: true },
  floor: String,
  room: String,
  description: String
}, opts));

const SLA = mongoose.model('SLA', new Schema({
  priority: { type: String, enum: ['Critical','High','Medium','Low'], unique: true, required: true },
  targetMinutes: { type: Number, required: true, min: 1 }
}, opts));

const ServiceRequest = mongoose.model('ServiceRequest', new Schema({
  requester: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  category: { type: Schema.Types.ObjectId, ref: 'Category', required: true },
  location: { type: Schema.Types.ObjectId, ref: 'Location', required: true },
  title: { type: String, required: true, trim: true, maxlength: 180 },
  description: { type: String, required: true },
  priority: { type: String, enum: ['Critical','High','Medium','Low'], default: 'Medium', index: true },
  status: { type: String, enum: ['Submitted','Assigned','In Progress','On Hold','Resolved','Closed','Rejected'], default: 'Submitted', index: true },
  slaDeadline: Date
}, opts));
ServiceRequest.schema.index({ status: 1, priority: 1, createdAt: -1 });

const Assignment = mongoose.model('Assignment', new Schema({
  request: { type: Schema.Types.ObjectId, ref: 'ServiceRequest', required: true, index: true },
  staff: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  assignedBy: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  active: { type: Boolean, default: true, index: true },
  assignedAt: { type: Date, default: Date.now }
}, opts));

const RequestUpdate = mongoose.model('RequestUpdate', new Schema({
  request: { type: Schema.Types.ObjectId, ref: 'ServiceRequest', required: true, index: true },
  updatedBy: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  oldStatus: String,
  newStatus: { type: String, required: true },
  remarks: String
}, opts));

const Comment = mongoose.model('Comment', new Schema({
  request: { type: Schema.Types.ObjectId, ref: 'ServiceRequest', required: true, index: true },
  user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  comment: { type: String, required: true }
}, opts));

const Notification = mongoose.model('Notification', new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  message: { type: String, required: true },
  eventType: { type: String, required: true },
  isRead: { type: Boolean, default: false, index: true }
}, opts));

const Feedback = mongoose.model('Feedback', new Schema({
  request: { type: Schema.Types.ObjectId, ref: 'ServiceRequest', required: true, unique: true },
  user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  rating: { type: Number, required: true, min: 1, max: 5 },
  comments: String
}, opts));

module.exports = { User, Department, Category, Location, SLA, ServiceRequest, Assignment, RequestUpdate, Comment, Notification, Feedback };
