const amqp=require('amqplib');let connection,channel;
async function getChannel(){
 if(channel)return channel;
 try{
  connection=await amqp.connect(process.env.RABBITMQ_URL||'amqp://guest:guest@localhost:5672');
  channel=await connection.createChannel();
  await channel.assertExchange('campusflow.events','topic',{durable:true});
  return channel;
 }catch(e){console.warn('RabbitMQ unavailable:',e.message);return null}
}
async function publishEvent(key,payload){
 const ch=await getChannel();
 if(ch)ch.publish('campusflow.events',key,Buffer.from(JSON.stringify(payload)),{persistent:true});
}
module.exports={getChannel,publishEvent};
