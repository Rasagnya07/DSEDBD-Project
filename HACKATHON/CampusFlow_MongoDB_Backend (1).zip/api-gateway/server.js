require('dotenv').config({path:require('path').resolve(__dirname,'../.env')});
const express=require('express'),cors=require('cors');const {createProxyMiddleware}=require('http-proxy-middleware');
const app=express();app.use(cors());app.use(express.json());
app.get('/health',(req,res)=>res.json({service:'api-gateway',status:'ok'}));
const mappings=[
 ['/api/auth',process.env.AUTH_SERVICE_URL||'http://localhost:5001','/auth'],
 ['/api/requests',process.env.REQUEST_SERVICE_URL||'http://localhost:5002','/requests'],
 ['/api/categories',process.env.REQUEST_SERVICE_URL||'http://localhost:5002','/categories'],
 ['/api/locations',process.env.REQUEST_SERVICE_URL||'http://localhost:5002','/locations'],
 ['/api/assignments',process.env.ASSIGNMENT_SERVICE_URL||'http://localhost:5003','/assignments'],
 ['/api/departments',process.env.ASSIGNMENT_SERVICE_URL||'http://localhost:5003','/departments'],
 ['/api/staff',process.env.ASSIGNMENT_SERVICE_URL||'http://localhost:5003','/staff'],
 ['/api/analytics',process.env.ASSIGNMENT_SERVICE_URL||'http://localhost:5003','/analytics'],
 ['/api/notifications',process.env.NOTIFICATION_SERVICE_URL||'http://localhost:5004','/notifications']
];
for(const[prefix,target,rewrite]of mappings)app.use(prefix,createProxyMiddleware({target,changeOrigin:true,pathRewrite:path=>path.replace(prefix,rewrite)}));
app.listen(5000,()=>console.log('API Gateway on 5000'));
