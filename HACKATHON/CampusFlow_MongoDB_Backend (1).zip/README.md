# CampusFlow Backend — MongoDB Edition

Hackathon-ready backend starter for a Smart Campus Service Management System.

## Stack
- Node.js 18+ and Express
- MongoDB with Mongoose
- JWT authentication and bcrypt password hashing
- API Gateway plus four independently runnable services
- RabbitMQ topic events for asynchronous notifications
- Docker Compose for MongoDB and RabbitMQ

The services use one shared MongoDB database (`campusflow`) for a simple hackathon setup, while each service has a separate responsibility and process. This demonstrates service separation and asynchronous integration without adding unnecessary database-operational overhead.

## Services and ports
| Component | Port |
|---|---:|
| API Gateway | 5000 |
| Auth Service | 5001 |
| Request Service | 5002 |
| Assignment Service | 5003 |
| Notification Service | 5004 |
| MongoDB | 27017 |
| RabbitMQ management UI | 15672 |

## Setup

1. Install Node.js 18+ and Docker Desktop.
2. Copy `.env.example` to `.env` in the project root.
3. Start MongoDB and RabbitMQ:
   ```bash
   docker compose up -d
   ```
4. Install packages:
   ```bash
   npm install --prefix auth-service
   npm install --prefix request-service
   npm install --prefix assignment-service
   npm install --prefix notification-service
   npm install --prefix api-gateway
   ```
5. Create demo accounts and sample campus data:
   ```bash
   npm run seed --prefix auth-service
   ```
6. Start each service in a separate terminal:
   ```bash
   npm run dev --prefix auth-service
   npm run dev --prefix request-service
   npm run dev --prefix assignment-service
   npm run dev --prefix notification-service
   npm run dev --prefix api-gateway
   ```
7. Set the frontend API base URL to `http://localhost:5000`.

## Demo accounts
- Student: `student@campusflow.demo` / `Student@123`
- Admin: `admin@campusflow.demo` / `Admin@123`
- Staff: `staff@campusflow.demo` / `Staff@123`

These are local demo credentials only. Change them before any public deployment.

## Main API routes through the gateway
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/profile`
- `POST /api/requests`
- `GET /api/requests`
- `GET /api/requests/:id`
- `PATCH /api/requests/:id/status`
- `POST /api/requests/:id/comments`
- `POST /api/requests/:id/feedback`
- `POST /api/assignments`
- `GET /api/assignments`
- `GET /api/departments`
- `GET /api/categories`
- `GET /api/locations`
- `GET /api/staff/workload`
- `GET /api/analytics/dashboard`
- `GET /api/notifications`
- `PATCH /api/notifications/:id/read`

Protected endpoints require `Authorization: Bearer YOUR_JWT`.

## Example request body
```json
{
  "title": "Wi-Fi not working",
  "description": "The network is unavailable in Lab 2.",
  "categoryId": "REPLACE_WITH_CATEGORY_OBJECT_ID",
  "locationId": "REPLACE_WITH_LOCATION_OBJECT_ID",
  "priority": "High"
}
```

Use the IDs returned by `GET /api/categories` and `GET /api/locations`.

## MongoDB collections
`users`, `departments`, `categories`, `locations`, `slas`, `servicerequests`, `assignments`, `requestupdates`, `comments`, `notifications`, `feedback`.

Mongoose schemas define validation, references, timestamps and indexes. The request workflow stores a separate update document for each status change, preserving its audit history.

## Distributed integration
The Request and Assignment services publish topic events to RabbitMQ. The Notification service consumes those events and stores user notifications in MongoDB. If RabbitMQ is temporarily unavailable, the core request operation can still complete; the service logs that event publishing was skipped. For production, add a transactional outbox, retries and dead-letter handling.

## Useful demo flow
1. Log in as the seeded student.
2. Fetch categories and locations.
3. Create a request.
4. Log in as admin and assign the request to the seeded staff member.
5. Log in as staff and change status to `In Progress`, then `Resolved`.
6. Log in as student, view notifications and submit feedback.

## Notes
- Default SLA targets: Critical 60 minutes, High 240 minutes, Medium 1440 minutes, Low 4320 minutes. These are configurable demo values.
- Request IDs are MongoDB ObjectIds. The frontend should display a short form if desired, but send the full ID to APIs.
- This is a hackathon starter. Test it in your environment and add HTTPS, production secrets, automated tests, stricter validation and durable event delivery before deployment.
