require('dotenv').config({path:require('path').resolve(__dirname,'../.env')});
const bcrypt=require('bcryptjs');const connectDB=require('../shared/db');
const {User,Department,Category,Location,SLA}=require('../shared/models');
(async()=>{
 try{
  await connectDB();
  const deptNames=['IT Department','Electrical Maintenance','Facilities','Housekeeping','Technical Support'];
  const depts={};
  for(const name of deptNames)depts[name]=await Department.findOneAndUpdate({name},{name},{upsert:true,new:true});
  const categoryRows=[
   ['Wi-Fi / Network','IT Department'],['Electrical','Electrical Maintenance'],['Plumbing','Facilities'],
   ['Cleaning','Housekeeping'],['Classroom Equipment','Technical Support'],['Hostel Maintenance','Facilities']
  ];
  for(const [name,d] of categoryRows)await Category.findOneAndUpdate({name},{name,department:depts[d]._id},{upsert:true,new:true});
  const locations=[
   {building:'Academic Block A',floor:'2',room:'Lab 2',description:'Computer laboratory'},
   {building:'Library',floor:'1',room:'Reading Hall',description:'Main library'},
   {building:'Hostel Block B',floor:'Ground',room:'Common Area',description:'Hostel common area'},
   {building:'Academic Block C',floor:'3',room:'Room 301',description:'Classroom'}
  ];
  for(const l of locations)if(!await Location.findOne(l))await Location.create(l);
  for(const [priority,targetMinutes] of [['Critical',60],['High',240],['Medium',1440],['Low',4320]])
   await SLA.findOneAndUpdate({priority},{priority,targetMinutes},{upsert:true,new:true});
  const users=[
   ['Niyathi Konduparthy','student@campusflow.demo','Student@123','Student',null],
   ['Campus Admin','admin@campusflow.demo','Admin@123','Admin',null],
   ['IT Support Staff','staff@campusflow.demo','Staff@123','Staff',depts['IT Department']._id]
  ];
  for(const [name,email,password,role,department] of users)
   await User.findOneAndUpdate({email},{name,email,passwordHash:await bcrypt.hash(password,12),role,department},{upsert:true,new:true});
  console.log('Seed completed. Demo accounts: student@campusflow.demo / Student@123; admin@campusflow.demo / Admin@123; staff@campusflow.demo / Staff@123');
  process.exit(0);
 }catch(e){console.error(e);process.exit(1)}
})();
