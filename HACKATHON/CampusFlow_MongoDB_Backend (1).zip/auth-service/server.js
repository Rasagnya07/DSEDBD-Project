require('dotenv').config({path:require('path').resolve(__dirname,'../.env')});
const express=require('express'),cors=require('cors'),bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken'),rateLimit=require('express-rate-limit');
const connectDB=require('../shared/db');const {User}=require('../shared/models');const {authenticate}=require('../shared/auth');const errors=require('../shared/errors');
const app=express();app.use(cors());app.use(express.json());
app.get('/health',(req,res)=>res.json({service:'auth-service',status:'ok'}));
app.post('/auth/register',rateLimit({windowMs:900000,limit:30}),async(req,res,next)=>{
 try{const{name,email,password,role='Student'}=req.body;
 if(!name||!email||!password||password.length<8)return res.status(400).json({message:'Name, email and password (8+ characters) are required'});
 if(!['Student','Faculty','Staff'].includes(role))return res.status(400).json({message:'Self-registration is limited to Student, Faculty or Staff'});
 const exists=await User.findOne({email});if(exists)return res.status(409).json({message:'Email already registered'});
 const user=await User.create({name,email,passwordHash:await bcrypt.hash(password,12),role});
 res.status(201).json({message:'User registered',user:{id:user._id,name:user.name,email:user.email,role:user.role}});
 }catch(e){next(e)}
});
app.post('/auth/login',async(req,res,next)=>{
 try{const{email,password}=req.body;const user=await User.findOne({email}).populate('department');
 if(!user||!await bcrypt.compare(password||'',user.passwordHash))return res.status(401).json({message:'Invalid email or password'});
 const token=jwt.sign({user_id:user._id,name:user.name,email:user.email,role:user.role,department_id:user.department?._id||null},process.env.JWT_SECRET||'development_secret_change_me',{expiresIn:process.env.JWT_EXPIRES_IN||'1d'});
 res.json({token,user:{id:user._id,name:user.name,email:user.email,role:user.role,department:user.department}});
 }catch(e){next(e)}
});
app.get('/auth/profile',authenticate,async(req,res,next)=>{
 try{const user=await User.findById(req.user.user_id).select('-passwordHash').populate('department');if(!user)return res.status(404).json({message:'User not found'});res.json(user)}catch(e){next(e)}
});
app.use(errors);
connectDB().then(()=>app.listen(5001,()=>console.log('Auth service on 5001'))).catch(e=>{console.error(e);process.exit(1)});
