require('dotenv').config({path:require('path').resolve(__dirname,'../.env')});
const express=require('express'),cors=require('cors');const connectDB=require('../shared/db');
const {ServiceRequest,Category,Location,SLA,RequestUpdate,Comment,Feedback,User}=require('../shared/models');
const {authenticate,allowRoles}=require('../shared/auth');const {publishEvent}=require('../shared/events');const errors=require('../shared/errors');
const app=express();app.use(cors());app.use(express.json());
app.get('/health',(req,res)=>res.json({service:'request-service',status:'ok'}));
app.get('/categories',async(req,res,next)=>{try{res.json(await Category.find().populate('department','name'))}catch(e){next(e)}});
app.get('/locations',async(req,res,next)=>{try{res.json(await Location.find())}catch(e){next(e)}});
app.post('/requests',authenticate,async(req,res,next)=>{
 try{const{title,description,categoryId,locationId,priority='Medium'}=req.body;
 if(!title||!description||!categoryId||!locationId)return res.status(400).json({message:'title, description, categoryId and locationId are required'});
 if(!['Critical','High','Medium','Low'].includes(priority))return res.status(400).json({message:'Invalid priority'});
 const [category,location,sla]=await Promise.all([Category.findById(categoryId),Location.findById(locationId),SLA.findOne({priority})]);
 if(!category||!location)return res.status(400).json({message:'Invalid categoryId or locationId'});
 const request=await ServiceRequest.create({requester:req.user.user_id,category:category._id,location:location._id,title,description,priority,slaDeadline:new Date(Date.now()+sla.targetMinutes*60000)});
 await RequestUpdate.create({request:request._id,updatedBy:req.user.user_id,oldStatus:null,newStatus:'Submitted',remarks:'Request created'});
 await publishEvent('request.created',{request_id:String(request._id),user_id:req.user.user_id,title});
 res.status(201).json({message:'Request created',request});
 }catch(e){next(e)}
});
app.get('/requests',authenticate,async(req,res,next)=>{
 try{let filter={};
 if(['Student','Faculty'].includes(req.user.role))filter.requester=req.user.user_id;
 if(req.user.role==='Staff'){
  const {Assignment}=require('../shared/models');
  const assigned=await Assignment.find({staff:req.user.user_id,active:true}).distinct('request');
  filter._id={$in:assigned};
 }
 const rows=await ServiceRequest.find(filter).sort({createdAt:-1}).populate('requester','name email').populate('category','name').populate('location');
 res.json(rows);
 }catch(e){next(e)}
});
app.get('/requests/:id',authenticate,async(req,res,next)=>{
 try{const item=await ServiceRequest.findById(req.params.id).populate('requester','name email').populate('category','name').populate('location');
 if(!item)return res.status(404).json({message:'Request not found'});
 if(['Student','Faculty'].includes(req.user.role)&&String(item.requester._id)!==String(req.user.user_id))return res.status(403).json({message:'Forbidden'});
 const [updates,comments]=await Promise.all([RequestUpdate.find({request:item._id}).sort({createdAt:1}).populate('updatedBy','name'),Comment.find({request:item._id}).sort({createdAt:1}).populate('user','name')]);
 res.json({request:item,updates,comments});
 }catch(e){next(e)}
});
app.patch('/requests/:id/status',authenticate,allowRoles('Staff','Admin'),async(req,res,next)=>{
 try{const{status,remarks=''}=req.body;const allowed=['Assigned','In Progress','On Hold','Resolved','Closed','Rejected'];
 if(!allowed.includes(status))return res.status(400).json({message:'Invalid status'});
 const item=await ServiceRequest.findById(req.params.id);if(!item)return res.status(404).json({message:'Request not found'});
 if(req.user.role==='Staff'){const {Assignment}=require('../shared/models');const assigned=await Assignment.exists({request:item._id,staff:req.user.user_id,active:true});if(!assigned)return res.status(403).json({message:'Request is not assigned to you'})}
 const oldStatus=item.status;item.status=status;await item.save();
 await RequestUpdate.create({request:item._id,updatedBy:req.user.user_id,oldStatus,newStatus:status,remarks});
 await publishEvent('request.status_changed',{request_id:String(item._id),user_id:String(item.requester),status});
 res.json({message:'Status updated',request:item});
 }catch(e){next(e)}
});
app.post('/requests/:id/comments',authenticate,async(req,res,next)=>{
 try{if(!req.body.comment)return res.status(400).json({message:'Comment is required'});
 const item=await ServiceRequest.findById(req.params.id);if(!item)return res.status(404).json({message:'Request not found'});
 if(['Student','Faculty'].includes(req.user.role)&&String(item.requester)!==String(req.user.user_id))return res.status(403).json({message:'Forbidden'});
 const comment=await Comment.create({request:item._id,user:req.user.user_id,comment:req.body.comment});res.status(201).json(comment);
 }catch(e){next(e)}
});
app.post('/requests/:id/feedback',authenticate,async(req,res,next)=>{
 try{const{rating,comments=''}=req.body;if(!Number.isInteger(rating)||rating<1||rating>5)return res.status(400).json({message:'Rating must be an integer from 1 to 5'});
 const item=await ServiceRequest.findById(req.params.id);if(!item)return res.status(404).json({message:'Request not found'});
 if(String(item.requester)!==String(req.user.user_id))return res.status(403).json({message:'Only the requester can submit feedback'});
 if(!['Resolved','Closed'].includes(item.status))return res.status(400).json({message:'Feedback is available after resolution'});
 const feedback=await Feedback.create({request:item._id,user:req.user.user_id,rating,comments});res.status(201).json(feedback);
 }catch(e){next(e)}
});
app.use(errors);connectDB().then(()=>app.listen(5002,()=>console.log('Request service on 5002'))).catch(e=>{console.error(e);process.exit(1)});
