# Interview Practice Platform — MongoDB backend

Separate Express REST API for the uploaded React/Vite frontend. The frontend has **not** been changed.

## Setup

1. Install Node.js 20+ and create a MongoDB Atlas database (or run MongoDB locally).
2. Open this backend folder in VS Code and run `npm install`.
3. Copy `.env.example` to `.env`. Set your real `MONGODB_URI` and a random `JWT_SECRET` of at least 32 characters. In Atlas, create a database user and permit your current IP in Network Access. Never commit `.env`.
4. Run `npm run seed` to add sample jobs, companies, HR questions and coding problems.
5. Run `npm run dev`. Test `http://localhost:5000/api/health`.

## API routes

| Method | Route | Body / purpose |
|---|---|---|
| POST | `/api/auth/register` | `{name,email,password,experienceLevel,yearsExperience}` |
| POST | `/api/auth/login` | `{email,password}` → JWT |
| GET | `/api/auth/me` | Current user |
| PATCH | `/api/users/me` | Update profile, skills, experience |
| POST | `/api/resumes/analyze` | `multipart/form-data` field `resume` (PDF/DOCX/TXT), OR JSON `{text}` |
| GET | `/api/resumes` | Your resume analyses |
| GET | `/api/jobs` | Job listings |
| GET | `/api/jobs/:slug` | Job and questions appropriate to user experience |
| GET | `/api/companies` | Companies |
| GET | `/api/companies/:slug` | Company and experience-specific questions |
| GET | `/api/questions/hr` | Experience-filtered HR questions |
| POST | `/api/interviews` | `{mode:"role"|"company"|"hr",targetId}` |
| GET | `/api/interviews` | Your sessions |
| GET | `/api/interviews/:id` | Your session |
| PATCH | `/api/interviews/:id/answers/:index` | `{answer}`; index starts at 0 |
| POST | `/api/interviews/:id/complete` | Finish; returns completion metrics |
| GET | `/api/coding/problems` | Problem list |
| GET | `/api/coding/problems/:slug` | Problem details and sample cases |
| POST | `/api/coding/submissions` | `{problemId,language,code}`; saves code, **does not execute** |
| GET | `/api/coding/submissions` | Your submissions |
| GET | `/api/dashboard` | Real user activity and streak |

All routes except `/api/health`, `/api/auth/register`, `/api/auth/login` require `Authorization: Bearer YOUR_JWT`.

## Connect the existing frontend (required)

The uploaded frontend currently uses local `mock*.js` files and a demo AuthContext. **It will not automatically use this backend just because both folders run.** Keep its JSX/CSS/layout and replace only data/auth handlers:

```js
const API = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
async function request(path, options={}) {
  const token = localStorage.getItem('authToken');
  const response = await fetch(API + path, {
    ...options,
    headers: {
      ...(token ? {Authorization:`Bearer ${token}`} : {}),
      ...(!(options.body instanceof FormData) ? {'Content-Type':'application/json'} : {}),
      ...options.headers
    }
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Request failed');
  return data;
}
```

1. Login: `request('/auth/login',{method:'POST',body:JSON.stringify({email,password})})`; save `token` and `user`. Register new users using `/auth/register`. Remove the demo login and guest bypass (or add a dedicated guest mode with no protected API access).
2. ResumeUpload: keep the selected `File` object, not just its name. Submit `FormData` with field `resume`, or `{text: pastedText}` to `/resumes/analyze`; pass the returned `matches` to MatchResults or fetch the saved analysis. Its returned scores are **keyword-based**, not ML or semantic AI scores.
3. MatchResults: use returned `matches` instead of `mockJobs`; keep `jobId` slug for routing.
4. Role/Company/HR: use `/jobs`, `/companies`, `/questions/hr` and create an interview session. Save typed or transcribed answers using PATCH; complete with POST. The existing record button is only a UI toggle: browser audio capture, speech-to-text and audio storage require additional work.
5. Coding: use `/coding/problems` and `/coding/submissions`; submissions are stored but **not graded or executed**. For real test-case execution, integrate a separately sandboxed judge (never run user-submitted code inside the API server).
6. Dashboard: fetch `/dashboard` instead of `mockStats.js`.

Example frontend `.env`: `VITE_API_URL=http://localhost:5000/api`. Restart Vite after editing.

## Honest scope

Implemented: persistent MongoDB models, JWT login/register, password hashing, resume PDF/DOCX/TXT text extraction, keyword skill matching, experience-specific interview questions, answer/session persistence, coding submission storage, dashboard counts and streaks, validation, CORS, upload limit, auth rate limit.

Not implemented: true AI resume parsing or semantic ranking; automatic interview quality scoring; microphone recording/transcription; actual coding execution and test grading; real external job listings; password-reset email. These require additional services and should not be represented as functional in the frontend until integrated.

Security note: avoid logging resumes and interview answers, protect MongoDB credentials, configure a real CORS origin, and delete uploaded personal data on request. In production, consider short-lived access tokens with secure HTTP-only refresh cookies instead of long-lived tokens in localStorage.
